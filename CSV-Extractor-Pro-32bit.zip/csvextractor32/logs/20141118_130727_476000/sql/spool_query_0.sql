CONNECT TO SAMPLE
EXPORT TO C:\\tmp\\dm_out\\Persons_pipe_datetime_1_20141118_130727_476000.data OF DEL MODIFIED BY NOCHARDEL COLDEL| 	select * from (select  t.* from (SELECT * FROM Persons_pipe_datetime_1) t ) v 
CONNECT RESET
