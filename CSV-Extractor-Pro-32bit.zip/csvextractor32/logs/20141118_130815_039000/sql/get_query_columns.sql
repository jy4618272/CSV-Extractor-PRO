set columnlabels on echo off feedback off serveroutput  off timing off
desc SELECT * FROM TERRY.Persons_pipe_datetime;