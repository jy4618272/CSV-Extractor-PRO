set columnlabels on echo off feedback off serveroutput  off timing off
desc SELECT * FROM (select *  
from TERRY.Persons_pipe_datetime);