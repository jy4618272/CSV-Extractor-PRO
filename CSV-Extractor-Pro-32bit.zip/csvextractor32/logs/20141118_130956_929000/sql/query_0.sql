SELECT * FROM TEST.Persons_sub_partitioned PARTITION(subpart100) LIMIT 14
INTO OUTFILE 'C:\\tmp\\dm_out\\TEST.Persons_sub_partitioned_subpart100.20141118_130956_929000.Shard-0.data'
FIELDS ENCLOSED BY '' TERMINATED BY '|' ESCAPED BY ''
LINES TERMINATED BY '\r\n';
SELECT ROW_COUNT();
