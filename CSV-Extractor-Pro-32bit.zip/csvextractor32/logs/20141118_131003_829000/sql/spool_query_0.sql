UNLOAD TO "c:\\Python27\\csvextractor_1235\\CSV_OUT\\Persons_pipe_datetime_1_20141118_131003_829000.data" DELIMITER '|' SELECT  * FROM (SELECT * FROM Persons_pipe_datetime_1) q;
