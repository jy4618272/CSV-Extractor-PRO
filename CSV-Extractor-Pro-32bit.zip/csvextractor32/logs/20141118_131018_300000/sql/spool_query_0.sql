CONNECT TO SAMPLE
EXPORT TO c:\\Python27\\csvextractor_1235\\CSV_OUT\\Persons_pipe_datetime_1_20141118_131018_300000.data OF DEL MODIFIED BY NOCHARDEL COLDEL| 	select * from (select  t.* from (SELECT * FROM Persons_pipe_datetime_1) t ) v 
CONNECT RESET
