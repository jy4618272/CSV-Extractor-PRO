CONNECT TO SAMPLE
EXPORT TO c:\\Python27\\csvextractor_1235\\CSV_OUT\\db2_query_20141118_131031_098000.data OF DEL MODIFIED BY NOCHARDEL COLDEL| 	select * from (select  t.* from (SELECT * FROM Persons_pipe_datetime_1) t ) v 
CONNECT RESET
