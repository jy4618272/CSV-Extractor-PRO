CONNECT TO SAMPLE
EXPORT TO c:\\Python27\\csvextractor_1235\\CSV_OUT\\spool_20141118_131046_459000_db2_query1.data OF DEL MODIFIED BY NOCHARDEL COLDEL| 	select * from (select  t.* from (SELECT * FROM Persons_pipe_datetime_1) t ) v 
CONNECT RESET
