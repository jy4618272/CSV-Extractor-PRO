UNLOAD TO "C:\\tmp\\dm_out\\Persons_pipe_datetime_1_20141118_131342_985000.data" DELIMITER '|' SELECT  * FROM (SELECT * FROM Persons_pipe_datetime_1) q;
