CONNECT TO SAMPLE
EXPORT TO C:\\tmp\\dm_out\\db2_query_20141118_131409_260000.data OF DEL MODIFIED BY NOCHARDEL COLDEL| 	select * from (select  t.* from (SELECT * FROM Persons_pipe_datetime_1) t ) v 
CONNECT RESET
