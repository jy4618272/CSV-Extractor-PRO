CONNECT TO SAMPLE
EXPORT TO C:\\tmp\\dm_out\\spool_20141118_131426_998000_db2_query1.data OF DEL MODIFIED BY NOCHARDEL COLDEL| 	select * from (select  t.* from (SELECT * FROM Persons_pipe_datetime_1) t ) v 
CONNECT RESET
